public abstract class Coordinate{
  int x = 0;
  int y = 0;
}
