
public class PlayerInput {
	Boolean a= false;
	Boolean b= false;
	Boolean c= false;
	Boolean d= false;
	Boolean e= false;
	Boolean f= false;
	Boolean g= false;
	Boolean h= false;
	Boolean i= false;
	Boolean j= false;
	Boolean k= false;
	Boolean l= false;
	Boolean m= false;
	Boolean n= false;
	Boolean o= false;
	Boolean p= false;
	Boolean q= false;
	Boolean r= false;
	Boolean s= false;
	Boolean t= false;
	Boolean u= false;
	Boolean v= false;
	Boolean w= false;
	Boolean x= false;
	Boolean y= false;
	Boolean z= false;
	Boolean up= false;
	Boolean down= false;
	Boolean left= false;
	Boolean right= false;
	Boolean space= false;
	public PlayerInput() {}
}
