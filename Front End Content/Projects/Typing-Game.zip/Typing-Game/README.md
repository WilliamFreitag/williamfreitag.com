# Typing-Game
A desktop game written in java using the javaFX library. The code makes use of a linked list and a queue to manage the computations and data storage in efficient ways.
